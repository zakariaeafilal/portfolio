<?php
// Include PhpSpreadsheet classes
require 'vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\IOFactory;

// MySQL connection parameters
$servername = "localhost";
$username = "root";
$password = "1234567890";
$database = "mini_pro";

// Create MySQL connection
$conn = new mysqli($servername, $username, $password, $database);

// Check MySQL connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Load Excel file
$excelFile = 'C:/xampp/htdocs/phpspreadsheet/test2.xlsx';

try {
    // Load Excel file
    $spreadsheet = IOFactory::load($excelFile);
    $worksheet = $spreadsheet->getActiveSheet();

    // Get highest row and column numbers containing data
    $highestRow = $worksheet->getHighestRow();
    $highestColumn = $worksheet->getHighestColumn();

    // Loop through each row of the worksheet
    for ($row = 2; $row <= $highestRow; $row++) {
        // Get cell values and insert into MySQL table
        $cellValues = $worksheet->rangeToArray('A' . $row . ':' . $highestColumn . $row, NULL, TRUE, FALSE)[0];
        $sql = "INSERT INTO user ( Nom, Titre, Mot_de_passe, position, login) VALUES (?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssss", $cellValues[0], $cellValues[1], $cellValues[2], $cellValues[3], $cellValues[4]);
        $stmt->execute();
    }

    echo "Data imported successfully!";
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}

// Close MySQL connection
$conn->close();
?>
