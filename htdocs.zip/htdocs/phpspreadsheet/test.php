<?php
// Include PhpSpreadsheet classes
require 'vendor/autoload.php';
    
use PhpOffice\PhpSpreadsheet\Reader\Xlsx;
use PhpOffice\PhpSpreadsheet\Shared\Date;

// MySQL connection parameters
$servername = "localhost";
$username = "root";
$password = "1234567890";
$database = "flsht";

// Create MySQL connection
$conn = new mysqli($servername, $username, $password, $database);

// Check MySQL connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$reader = new Xlsx();
$reader->setReadDataOnly(true);
// Load Excel file
$excelFile = 'C:/xampp/htdocs/phpspreadsheet/REINSCRIPTION PHI 2023-2024 (1).xlsx';

try {


require 'vendor/autoload.php';

$reader = new Xlsx();
$spreadsheet = $reader->load($excelFile);
$activeSheet = $spreadsheet->getActiveSheet();

foreach (['G1', 'G2', 'G3', 'G4', 'G5', 'G6', 'G7', 'G8', 'G9'] as $pCoordinate) {
    $pCell =$activeSheet->getCell($pCoordinate);
    $isDateTime = Date::isDateTime($pCell);
    
    printf(
        '%s isDateTime: %s, value: %s'.PHP_EOL,
        $pCoordinate,
        $isDateTime ? 'Yes' : 'No',
        $pCell->getValue()
    );
    }
    if (Date::isDateTime($pCell)) {
        echo var_dump( Date::excelToDateTimeObject($pCell->getValue())->format('d-m-Y H:i:s')) . "\n";
    }
    echo "Data imported successfully!";
}catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}

// Close MySQL connection
$conn->close();
?>
