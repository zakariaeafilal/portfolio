<?php
require 'vendor/autoload.php';
$test = "lol";
$test2 = 2 ;
use Dompdf\Dompdf;


$html = "   
<html>
<head>
    <style>
        h1 {
            color: blue;
        }
        p {
            font-size: 18px;
            line-height: 1.5;
        }
    </style>
</head>
<body>
    <h1>Hello, $test World lololo!</h1>
    <p> tototstyles.$test2</p>
</body>
</html>";

$dompdf = new Dompdf();
$dompdf->loadHtml($html);
$dompdf->setPaper('A4', 'portrait');


$dompdf->render();



$pdfContent = $dompdf->output();

$name = "test11.pdf";
$pdfFilePath = 'C:/xampp/htdocs/phpspreadsheet/'.$name;

// Write PDF content to a file
file_put_contents($pdfFilePath, $pdfContent);

echo "PDF saved successfully at $pdfFilePath";



?>