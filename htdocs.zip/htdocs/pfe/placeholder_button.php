<?php

session_start();


if(isset($_SESSION['login']) && ($_SESSION['logint'] >= time()))
{
if($_SESSION['login'] == "login")
{
//echo"hi";
//print_r($_SESSION['favcolor']);  
//echo "<a href='logout_user.php'>Click here to log out</a>";
}
else
{
session_unset();
session_destroy();
    echo"hi2";
    print_r($_SESSION['favcolor']);
}
}
else
{
//echo "login";
//echo "<a href='login.php'>Click here to login</a>";
echo "<a href='logout_user.php'>Click here to login</a>";
}
// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "1234567890";
$dbname = "flsht";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get search value from POST request
$searchValue = $_POST["searchValue"];
if($searchValue != 1)

{
// Prepare and execute SQL query

/*$sql = "UPDATE student SET eligibility = CURRENT_TIME WHERE CODAPO = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $searchValue);
$stmt->execute();

*/
$stmt->close();
}


// Close statement and connection

$conn->close();
?>
