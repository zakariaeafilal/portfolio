<?php
//stat session
session_start();
//destroy sessing
session_destroy();
//Desplay the logout message and link to the login page.
?>
<!DOCTYPE html>
<html lang="en">
<head>

<link rel="stylesheet" href="css_user.css">

<meta charset="UTF-8">
<title>PHP Live MySQL Database Search</title>
</head>
<body id="logout_body">
<div id="logout_panel">
        <p id="logout_message">You have been logged out</p>        
        <a id="login_page" href="login.php">Go back to login page</a>
</div>

<script>
function getCookie(name) {
  const value = `; ${document.cookie}`;
  const parts = value.split(`; ${name}=`);
  if (parts.length === 2) return parts.pop().split(';').shift();
}
    if(getCookie("darkmodec") == "treu")
{
    document.body.style.backgroundColor = "rgb(31 41 44 / 94%)" ;
document.getElementById("logout_panel").style.backgroundColor = "rgb(55 65 81 / 90%)" ;

}
</script>
</body>
</html>

