<?php
session_start();


if(isset($_SESSION['login']) && ($_SESSION['logint'] >= time()))
{
if($_SESSION['login'] == "login")
{
   
}
else
{
session_unset();
session_destroy();
    echo"hi2";
    print_r($_SESSION['favcolor']);
}
}
else
{
//echo "login";
header("Location: logout_user.php");
}

use Dompdf\Dompdf;
use Dompdf\Options;

require '../phpspreadsheet/vendor/autoload.php';

$options = new options();
$options->set('chroot',realpath(''));
//define("DOMPDF_ENABLE_REMOTE", TRUE);
//define("DOMPDF_PDF_BACKEND", "CPDF");


// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "1234567890";
$dbname = "flsht";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get search value from POST request
$searchValue = $_POST["rid"];

$sql1 = "SELECT request_status FROM request WHERE CODAPO = ?";
$stmt1 = $conn->prepare($sql1);
$stmt1->bind_param("s", $searchValue);
$stmt1->execute();
$result1 = $stmt1->get_result();
$test = 1 ;

if ($result1->num_rows > 0) {
    // Output data of each row
    while($row1 = $result1->fetch_assoc()) 
    {            
        $search = $row1["request_status"];


            $test = strcmp($search, "wating") ;
            
    }
}
if($test == 0)
{
if( isset($_SESSION['login']) && ($_SESSION['logint'] >= time()))
{
// Prepare and execute SQL query
$sql = "SELECT * FROM student WHERE CODAPO = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $searchValue);
$stmt->execute();
$result = $stmt->get_result();

// Display search results
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
       // echo "<p>ID: " . $row["S_ID"] . ", Value: " . $row["Nom"] . "</p>";
    

       $NOM = ucfirst($row["NOM"]) ;
       $PRENOM = ucfirst($row["PRENOM"]) ;
       $CIN = ucfirst($row["CIN"]) ;
       $CNE = ucfirst($row["CNE"]) ;
       $CODAPO = $row["CODAPO"] ;
       $DATE_NAIS = $row["DATE_NAIS"] ;
       $LIEU_NAIS = ucfirst($row["LIEU_NAIS"]) ;
       $dat =  (date("Y")-1)."/".date("Y");
       $date = new DateTime(); 
  
        // Extract day, month, and year 
        $day = $date->format('d'); 
        $month = $date->format('m'); 
        $year = $date->format('Y'); 
       $tim = $day."/".$month."/".$year;

       $filer = $row["ETAPE3"];
       $filerf1 ="";
       $filerf2 ="";
       //all filer translation ->
       {
        if($filer == "LFGO1")
        {
         $filerf1 ="DEUG ETUD FOND GÉOGRAPHIE";
         $filerf2 ="Année : 1º année Licence DEUG des Études en Géographie";
        }
        if($filer == "LFGO2")
        {
         $filerf1 ="DEUG ETUD FOND GÉOGRAPHIE";
         $filerf2 ="Année : 2º année Licence DEUG des Études en Géographie";
        }
        if($filer == "LFGO3")
        {
         $filerf1 ="ETUD FOND GÉOGRAPHIE";
         $filerf2 ="Année : 3º année Licence des Études en Géographie";
        }
        if($filer == "LFEI1")
        {
         $filerf1 ="DEUG ETUD FOND ISLAMIQUES";
         $filerf2 ="Année : 1º année Licence DEUG des Études Islamiques";
        }
        if($filer == "LFEI2")
        {
         $filerf1 ="DEUG ETUD FOND ISLAMIQUES";
         $filerf2 ="Année : 2º année Licence DEUG des Études Islamiques";
        }
        if($filer == "LFEI3")
        {
         $filerf1 ="ETUD FOND ISLAMIQUES";
         $filerf2 ="Année : 3º année Licence des Études Islamiques";
        }
        if($filer == "LFHC1")
        {
         $filerf1 ="DEUG ETUD FOND HISTOIRE ET CIVILISATION";
         $filerf2 ="Année : 1º année Licence DEUG des Études en Histoire et civilisation";
        }
        if($filer == "LFHC2")
        {
         $filerf1 ="DEUG ETUD FOND HISTOIRE ET CIVILISATION";
         $filerf2 ="Année : 2º année Licence DEUG des Études en Histoire et civilisation";
        }
        if($filer == "LFHC3")
        {
         $filerf1 ="ETUD FOND HISTOIRE ET CIVILISATION";
         $filerf2 ="Année : 3º année Licence des Études en Histoire et civilisation";
        }
        if($filer == "LFEA1")
        {
         $filerf1 ="DEUG ETUD FOND ARABES";
         $filerf2 ="Année : 1º année Licence DEUG des Études arabes ";
        }
        if($filer == "LFEA2")
        {
         $filerf1 ="DEUG ETUD FOND ARABES";
         $filerf2 ="Année : 2º année Licence DEUG des Études arabes";
        }
        if($filer == "LFAA3")
        {
         $filerf1 ="ETUD FOND ARABES : LITERATUR ";
         $filerf2 ="Année : 3º année Licence des Études arabes : literatur ";
        }
        if($filer == "LFAL3")
        {
         $filerf1 ="ETUD FOND ARABES : LINGUISTIQUES ";
         $filerf2 ="Année : 3º année Licence des Études arabes : linguistiques ";
        }
        if($filer == "LFFI1")
        {
         $filerf1 ="DEUG ETUD FOND PHILOSOPHIE";
         $filerf2 ="Année : 1º année Licence DEUG des Études en Philosophie";
        }
        if($filer == "LFFI2")
        {
         $filerf1 ="DEUG ETUD FOND PHILOSOPHIE";
         $filerf2 ="Année : 2º année Licence DEUG des Études en Philosophie";
        }
        if($filer == "LFFI3")
        {
         $filerf1 ="ETUD FOND PHILOSOPHIE";
         $filerf2 ="Année : 3º année Licence des Études en Philosophie";
        }
        if($filer == "LFSS1")
        {
         $filerf1 ="DEUG ETUD FOND SOCIOLOGIE";
         $filerf2 ="Année : 1º année Licence DEUG des Études en Sociologie";
        }
        if($filer == "LFSS2")
        {
         $filerf1 ="DEUG ETUD FOND SOCIOLOGIE";
         $filerf2 ="Année : 2º année Licence DEUG des Études en Sociologie";
        }
        if($filer == "LFSS3")
        {
         $filerf1 ="ETUD FOND SOCIOLOGIE";
         $filerf2 ="Année : 3º année Licence des Études en Sociologie";
        }
        if($filer == "LFEH1")
        {
         $filerf1 ="DEUG ETUD FOND HISPANIQUES";
         $filerf2 ="Année : 1º année Licence DEUG des Études Hispaniques";
        }
        if($filer == "LFEH2")
        {
         $filerf1 ="DEUG ETUD FOND HISPANIQUES";
         $filerf2 ="Année : 2º année Licence DEUG des Études Hispaniques";
        }
        if($filer == "LFEH3")
        {
         $filerf1 ="ETUD FOND HISPANIQUES";
         $filerf2 ="Année : 3º année Licence des Études Hispaniques";
        }
        if($filer == "LFES1")
        {
         $filerf1 ="DEUG ETUD FOND D'ANGLAIS";
         $filerf2 ="Année : 1º année Licence DEUG des Études d'anglais";
        }
        if($filer == "LFES2")
        {
         $filerf1 ="DEUG ETUD FOND D'ANGLAIS";
         $filerf2 ="Année : 2º année Licence DEUG des Études d'anglais";
        }
        if($filer == "LFET3")
        {
         $filerf1 ="ETUD FOND D'ANGLAIS : LITERATUR ";
         $filerf2 ="Année : 3º année Licence des Études d'anglais : literatur ";
        }
        if($filer == "LFEL3")
        {
         $filerf1 ="ETUD FOND D'ANGLAIS : linguistiques";
         $filerf2 ="Année : 3º année Licence des Études d'anglais : linguistiques";
        }
        if($filer == "LFEF1")
        {
         $filerf1 ="DEUG ETUD FOND FRANÇAISES";
         $filerf2 ="Année : 1º année Licence DEUG des Études Françaises";
        }
        if($filer == "LFEF2")
        {
         $filerf1 ="DEUG ETUD FOND FRANÇAISES";
         $filerf2 ="Année : 2º année Licence DEUG des Études Françaises";
        }
        if($filer == "LFEF3")
        {
         $filerf1 ="ETUD FOND FRANÇAISES";
         $filerf2 ="Année : 3º année Licence des Études Françaises";
        }
        if($filer == "LLMM1")
        {
         $filerf1 ="ETUD FOND MARRUECOS, MULTICULTURALIDAD Y PANHISPANISMO";
         $filerf2 ="Année : 1º année des Études en Marruecos, Multiculturalidad y Panhispanismo";
        }
        if($filer == "LLGC1")
        {
         $filerf1 ="ETUD FOND GESTION CULTURAL Y PATRIMONIO";
         $filerf2 ="Année : 1º année des Études en Gestion Cultural y Patrimonio";
        }
        if($filer == "LLLC1")
        {
         $filerf1 ="ETUD FOND LINGUISTICS AND COMMUNICATION";
         $filerf2 ="Année : 1º année des Études en Linguistics and Communication";
        }
        if($filer == "LLLS1")
        {
         $filerf1 ="ETUD FOND LITERARY AND CULTURAL STUDIES";
         $filerf2 ="Année : 1º année des Études en Literary and Cultural Studies";
        }
        if($filer == "LLCA1")
        {
         $filerf1 ="ETUD FOND COMMUNICATION, ARTS ET MÉDIAS";
         $filerf2 ="Année : 1º année des Études en Communication, Arts et Médias";
        }
        if($filer == "LLTP1")
        {
         $filerf1 ="ETUD FOND THÉORIE ET PRATIQUE LITTÉRAIRES";
         $filerf2 ="Année : 1º année des Études en Théorie et Pratique Littéraires";
        }
        if($filer == "LLAC1")
        {
         $filerf1 ="ETUD FOND L'ACTEUR SOCIAL ET LE CHANGEMENT CULTUREL";
         $filerf2 ="Année : 1º année des Études en L'acteur social et le changement culturel";
        }
        if($filer == "LLDP1")
        {
         $filerf1 ="ETUD FOND DOMAINES DE LA PHILOSOPHIE CONTEMPORAINE";
         $filerf2 ="Année : 1º année des Études en Domaines de la philosophie contemporaine";
        }
        if($filer == "LLAD1")
        {
         $filerf1 ="ETUD FOND AMÉNAGEMENT ET DÉVELOPPEMENT DU TERRITOIRE ";
         $filerf2 ="Année : 1º année des Études en Aménagement et développement du territoire ";
        }
        if($filer == "LLEC1")
        {
         $filerf1 ="ETUD FOND  ENVIRONNEMENT ET ESPACE";
         $filerf2 ="Année : 1º année des Études en  Environnement et Espace";
        }
        if($filer == "LLHC1")
        {
         $filerf1 ="ETUD FOND HISTOIRE MODERNE";
         $filerf2 ="Année : 1º année des Études en Histoire moderne";
        }
        if($filer == "LLPA1")
        {
         $filerf1 ="ETUD FOND PATRIMOINE ET ARCHÉOLOGIE";
         $filerf2 ="Année : 1º année des Études en Patrimoine et archéologie";
        }
        if($filer == "LLLA1")
        {
         $filerf1 ="ETUD FOND ARABES : LETTRES ET ARTS";
         $filerf2 ="Année : 1º année des Études en Arabes : Lettres et Arts";
        }
        if($filer == "LLLN1")
        {
         $filerf1 ="ETUD FOND ARABES : LINGUISTIQUES";
         $filerf2 ="Année : 1º année des Études en Arabes : Linguistiques";
        }
        if($filer == "LLEP1")
        {
         $filerf1 ="ETUD FOND JURIDIQUES ET INTELLECTUELLES";
         $filerf2 ="Année : 1º année des Études juridiques et intellectuelles";
        }
        if($filer == "LLPC1")
        {
         $filerf1 ="ETUD FOND PSYCHOLOGIE CLINIQUE";
         $filerf2 ="Année : 1º année des Études en Psychologie clinique";
        }
        if(($filerf1 == "") && ($filerf2 == ""))
        {
         $filerf1 ="filière inconnue : ".$filer;
         $filerf2 ="filière inconnue : ".$filer;
        }
     }
       //html for the pdf generated
$html = '   
<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="utf-8"/>
<title>PHP Live MySQL Database Search</title>


    <style>

        p {
            font-size: 18px;
            line-height: 1.5;
        }
        body
        {
            
        }
        #div1
        {
            text-align: center;
            font-size: 3vh;
        }
        #div2
        {
            margin-left: 1cm;
        }
        .info
        {
            font-weight: bold;
            margin-left: 0.5vh;
        }
        #infox
        {
            font-weight: bold;
        }
        #im1
        {
            height: 3cm;
        }
        #im2
        {
            width: 10cm;
            text-align: center;
        }
        #imn
        {
            line-height: 1;
        }
        #imn1
        {
            line-height: 1;
            font-weight: bold;
        }
        table
        {
            padding-left: 1cm;
        }
    </style>
</head>
<body>
<table>
        <tr>
        <td id="im1">     
        <img id="im1" src="coat_of_arms.jpg" >
        </td>
        <td id="im2">     
            <p id="imn1">Royaume du Maroc</p>
            <p id="imn"> Ministère de l\'Enseignement Supérieur,</p>
            <p id="imn">de la Recherche Scientifique et de l\'Innovation</p>
        </td>
        <td id="im1">     
        <img id="im1" src="logoflsht.jpg" >
        </td>
        </tr>
</table>
<div id="div1">
    <h1>Attestation de Reinscription</h1>
</div>
<div id="div2">
    <P>Le Doyen de la Faculté des Lettres et des Sciences Humaines atteste que l\'étudiant(e) :</P>
    <br>
    <p> Nom et Prénom : <span class="info">'.$NOM.' '.$PRENOM.'</span> </p>   
    <p>Numéro de la cate d\'identité nationale : <span class="info">'.$CIN.'</span> </p>
    <p>Code nationale de l\'étudiant : <span class="info">'.$CNE.'</span></p>
    <p>Num étudiant : <span class="info">'.$CODAPO.'</span></p>  
    <p>Né le <span class="info">'.$DATE_NAIS.'</span> à <span class="info">'.$LIEU_NAIS.'</span></p>    
    <p>Poursuit ses études à la Faculté des Lettres et des Sciences Humaines - Tétouan pour l\'année universitaire : <span class="info">'.$dat.'</span></p>
    <br>
    <p>Filiére : <span class="info">'.$filerf1.'</span></p>
    <p class="info">'.$filerf2.'</p>
    <br>
<span id="div1">  
    <p>Fait à Tétouan le : <span class="info">'.$tim.'</span></p>
</span>
<span id="div1">
        <p id="infox">le doyen</p>
</span>
</body>
</html>';

$dompdf = new Dompdf($options);
$html = mb_convert_encoding($html, 'HTML-ENTITIES', 'UTF-8');


$dompdf->loadHtml($html);
//$dompdf->set_option('isRemotEnabled',true);
$dompdf->setPaper('A4', 'portrait');


$dompdf->render();



$pdfContent = $dompdf->output();

$name = $searchValue.".pdf";
$pdfFilePath = 'C:/xampp/htdocs/pfe/data/'.$name;
$pdfFilePath2 = 'data/'.$name;

// Write PDF content to a file
file_put_contents($pdfFilePath, $pdfContent);
$sql = "UPDATE request SET request_status = 'printed in wating' WHERE CODAPO = ? ";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $searchValue);
$stmt->execute();
echo "<script type=\"text/javascript\">window.open('$pdfFilePath2','_blank');location.href = \"dashboard.php\";</script>";

//$dompdf->stream($pdfFilePath ,array('Attachment'=>0));
//echo "PDF saved successfully at $pdfFilePath";

//header("Location: dashboard.php");


}
} else {
    header("Location: dashboard.php");
}
$stmt->close();
}
}
else
{
    header("Location: dashboard.php");
}
// Close statement and connection
$conn->close();

?>
