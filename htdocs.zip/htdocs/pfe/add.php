<?php
session_start();


if(isset($_SESSION['login']) && ($_SESSION['logint'] >= time()))
{
if($_SESSION['login'] == "login")
{
//echo"hi";
//print_r($_SESSION['favcolor']);  
//echo "<a href='logout_user.php'>Click here to log out</a>";
}
else
{
session_unset();
session_destroy();
    echo"hi2";
    print_r($_SESSION['favcolor']);
}
}
else
{
//echo "login";
//echo "<a href='login.php'>Click here to login</a>";
header("Location: logout_user.php");
}


$sname= "localhost";

$unmae= "root";

$password = "1234567890";

$db_name = "flsht";

$conn = mysqli_connect($sname, $unmae, $password, $db_name);

if (!$conn) {

    echo "Connection failed!";

}


if (isset($_POST['email1']) && isset($_POST['pasworf1'])) {

    function validate($data){

       $data = trim($data);

       $data = stripslashes($data);

       $data = htmlspecialchars($data);

       return $data;

    }

    $login = validate($_POST['email1']);

    $pass = validate($_POST['pasworf1']);

    if (empty($login)) {
        
        header("Location: data.php?error=User rmail is required");
        exit();

    }else if(empty($pass)){
        header("Location: data.php?error=Password is required");
        exit();
        

    }else{
        $hashed_password = password_hash($pass, PASSWORD_DEFAULT);
        if(isset($_POST['checkbox1']) && ($_POST['checkbox1'] == "admin"))
        {
            $sql = "INSERT INTO user ( Email, password, position) VALUES ('$login', '$hashed_password', 'admin')";
        }
        else
        {
            $sql = "INSERT INTO user ( Email, password) VALUES ('$login', '$hashed_password')";
        }
        
        try
        {
            if (mysqli_query($conn, $sql)) {

            header("Location: data.php");

            

        }else{

            header("Location: data.php?error=Incorect ");

            exit();

        }
        }
        catch(Exception $e) {
            header("Location: data.php?error=".$e->getMessage());
          }

        

    }

}else{
    
    header("Location: data.php");

    exit();

}
?>