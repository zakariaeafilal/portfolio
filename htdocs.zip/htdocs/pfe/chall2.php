<?php 

session_start();


if(isset($_SESSION['login']) && ($_SESSION['logint'] >= time()))
{
if($_SESSION['login'] == "login")
{
//echo"hi";
//print_r($_SESSION['favcolor']);  
//echo "<a href='logout_user.php'>Click here to log out</a>";
}
else
{
session_unset();
session_destroy();
    echo"hi2";
    print_r($_SESSION['favcolor']);
}
}
else
{
//echo "login";
//echo "<a href='login.php'>Click here to login</a>";
header("Location: logout_user.php");
}


$servername = "localhost";
$username = "root";
$password = "1234567890";
$dbname = "flsht";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$searchValue = $_POST["rid"];


$sql = "DELETE FROM request WHERE CODAPO  = ? ";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $searchValue);
$stmt->execute();
$sql = "UPDATE student SET eligibility = CURRENT_TIME WHERE CODAPO = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $searchValue);
$stmt->execute();

header("Location: dashboard.php");
?>