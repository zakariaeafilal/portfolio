<?php 

session_start();

if(isset($_SESSION['favcolor']) && ($_SESSION['favcolor'] != "admin"))
{
    header("Location: dashboard.php");
}
if(isset($_SESSION['login']) && ($_SESSION['logint'] >= time()))
{
if($_SESSION['login'] == "login")
{
//echo"hi";
//print_r($_SESSION['favcolor']);  
//echo "<a href='logout_user.php'>Click here to log out</a>";
}
else
{
session_unset();
session_destroy();
    echo"hi2";
    print_r($_SESSION['favcolor']);
}
}
else
{
//echo "login";
//echo "<a href='login.php'>Click here to login</a>";
header("Location: logout_user.php");
}


//(isset($_COOKIE["logint"]))
  

$servername = "localhost"; // MySQL server address
$username = "root"; // MySQL username
$password = "1234567890"; // MySQL password
$dbname = "flsht"; // Database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if(isset($_POST['filer']))
{
    $filler = $_POST['filer'];
            try
            {
                $sql4 = "UPDATE student_1 SI1, student SI SET SI1.eligibility = SI.eligibility WHERE SI1.CODAPO = SI.CODAPO";
                $conn -> query($sql4);
                
            }
            catch(Exception $e)
            {
            header("Location: data.php?error=". $e->getMessage());
            }
            try
            {
                $sql3 = "DELETE FROM student WHERE CODAPO IN (SELECT CODAPO FROM student_1) AND DIPLOME ='$filler' ";
                $conn -> query($sql3);
                
            }
            catch(Exception $e)
            {
            header("Location: data.php?error=". $e->getMessage());
            }
            try
            {
                $sql2 = "INSERT INTO student ( CODIND, CODAPO, CNE, NOM, PRENOM, CIN, DATE_NAIS, LIEU_NAIS, SEXE, NATIONALITE, COD_BAC, LIB_BAC, ANNEE_BAC, DIPLOME, NI, AUTOMNE, PRINTEMPS, ETAPE3, ETAPE2, ETAPE1 ,eligibility) SELECT CODIND, CODAPO, CNE, NOM, PRENOM, CIN, DATE_NAIS, LIEU_NAIS, SEXE, NATIONALITE, COD_BAC, LIB_BAC, ANNEE_BAC, DIPLOME, NI, AUTOMNE, PRINTEMPS, ETAPE3, ETAPE2, ETAPE1, eligibility FROM student_1 ";
                $conn -> query($sql2);


                
            }
            catch(Exception $e)
            {
            header("Location: data.php?error=". $e->getMessage());
            }
            
            $conn->close();
            header("Location: data.php?error=complite");

        }
        else{
    
            header("Location: data.php");
        
            exit();
        
        }
?>