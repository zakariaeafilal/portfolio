<?php

session_start();

if(isset($_SESSION['favcolor']) && ($_SESSION['favcolor'] != "admin"))
{
    header("Location: dashboard.php");
}
if(isset($_SESSION['login']) && ($_SESSION['logint'] >= time()))
{
if($_SESSION['login'] == "login")
{
//echo"hi";
//print_r($_SESSION['favcolor']);  
//echo "<a href='logout_user.php'>Click here to log out</a>";
}
else
{
session_unset();
session_destroy();
    echo"hi2";
    print_r($_SESSION['favcolor']);
}
}
else
{
//echo "login";
//echo "<a href='login.php'>Click here to login</a>";
header("Location: logout_user.php");
}
    if(!isset($_COOKIE["setting"]))
    {
        setcookie("darkmodec", "falss", time() + ( 365 * 24 * 60 * 60), '/');
    }

    if(isset($_POST['darkmodec']) && ($_POST['darkmodec'] == "darkmodec"))
    {
        setcookie("darkmodec", "treu", time() + ( 365 * 24 * 60 * 60), '/');
    }
    else
    {
        setcookie("darkmodec", "falss", time() + ( 365 * 24 * 60 * 60), '/');
    }
    if(!isset($_COOKIE["setting2"]))
    {
        setcookie("number", 10, time() + ( 365 * 24 * 60 * 60), '/');
    }
    if(isset($_POST['quantity']) )
    {
        setcookie("number", $_POST['quantity'], time() + ( 365 * 24 * 60 * 60), '/');
    }

    header("Location: setting_user.php");


?>