<?php
session_start();


if(isset($_SESSION['login']) && ($_SESSION['logint'] >= time()))
{
if($_SESSION['login'] == "login")
{
//echo"hi";
//print_r($_SESSION['favcolor']);  
//echo "<a href='logout_user.php'>Click here to log out</a>";
}
else
{
session_unset();
session_destroy();
    echo"hi2";
    print_r($_SESSION['favcolor']);
}
}
else
{
//echo "login";
//echo "<a href='login.php'>Click here to login</a>";
header("Location: logout_user.php");
}


$sname= "localhost";

$unmae= "root";

$password = "1234567890";

$db_name = "flsht";

$conn = mysqli_connect($sname, $unmae, $password, $db_name);

if (!$conn) {

    echo "Connection failed!";

}


if (isset($_POST['uid'])) {

    function validate($data){

       $data = trim($data);

       $data = stripslashes($data);

       $data = htmlspecialchars($data);

       return $data;

    }

    $uid = validate($_POST['uid']);


    if (empty($uid)) {
        
        header("Location: data.php?error=U_ID is required");
        exit();

    }else{
        
        
            $sql = "DELETE FROM user WHERE U_ID='$uid'";
        
        
        


        if (mysqli_query($conn, $sql)) {


            header("Location: data.php");


        }else{

            header("Location: data.php?error=Incorect ");

            exit();

        }

    }

}else{
    
    header("Location: data.php");

    exit();

}
?>