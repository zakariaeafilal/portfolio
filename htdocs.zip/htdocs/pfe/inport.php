<?php
session_start();


if(isset($_SESSION['login']) && ($_SESSION['logint'] >= time()))
{
if($_SESSION['login'] == "login")
{
//echo"hi";
//print_r($_SESSION['favcolor']);  
//echo "<a href='logout_user.php'>Click here to log out</a>";
}
else
{
session_unset();
session_destroy();
    echo"hi2";
    print_r($_SESSION['favcolor']);
}
}
else
{
//echo "login";
//echo "<a href='login.php'>Click here to login</a>";
header("Location: logout_user.php");
}

require '../phpspreadsheet/vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Shared\Date;
$dat =  (date("Y")-1)."-".date("Y");

if (!file_exists('uploads/'.$dat)) {
    mkdir('uploads/'.$dat, 0777, true);
}
$target_dir = "uploads/".$dat."/";
$target_file = $target_dir . basename($_FILES["link"]["name"]);
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

// Check if image file is a actual image or fake image
if(isset($_POST["submit"])) {
    $uploadOk = 1;
}

// Check if file already exists
if (file_exists($target_file)) {
   header("Location: data.php?error=Sorry, file already exists.");
  $uploadOk = 0;
}


// Allow certain file formats
if($imageFileType != "xlsx" && $imageFileType != "xlsm" ) {
  header("Location: data.php?error=Sorry, only xlsx, xlsm files are allowed.");
  $uploadOk = 0;
}

// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
  header("Location: data.php?error=Sorry, your file was not uploaded.");
// if everything is ok, try to upload file
} else {
  if (move_uploaded_file($_FILES["link"]["tmp_name"], $target_file)) {
    //echo "The file ". htmlspecialchars( basename( $_FILES["link"]["name"])). " has been uploaded.";
  } else {
    header("Location: data.php?error=Sorry, there was an error uploading your file.");
  }
}




$servername = "localhost";
$username = "root";
$password = "1234567890";
$database = "flsht";

$conn = new mysqli($servername, $username, $password, $database);

// Check MySQL connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_FILES["link"])) {

    /*function validate($data){

       $data = trim($data);

       $data = stripslashes($data);

       $data = htmlspecialchars($data);

       return $data;

    }

    $uid = validate($_POST['uid']);
    
    
    $add = "";
    $dell = "";
    $updat = "";
    $filler = "";
    */
    $link = htmlspecialchars( basename( $_FILES["link"]["name"]));
    if (empty($link)) {
        
        header("Location: data.php?error=link is required");
        exit();

    }else{
        
        $conn -> query("DELETE FROM student_1");
            
        $excelFile = 'C:/xampp/htdocs/pfe/uploads/'.$dat.'/'.htmlspecialchars( basename( $_FILES["link"]["name"]));

        try {
            // Load Excel file
            $spreadsheet = IOFactory::load($excelFile);
            $worksheet = $spreadsheet->getActiveSheet();

            // Get highest row and column numbers containing data
            $highestRow = $worksheet->getHighestRow();
            $highestColumn = $worksheet->getHighestColumn();
        
            // Loop through each row of the worksheet
            for ($row = 8; $row <= $highestRow; $row++) {
                // Get cell values and insert into MySQL table
                $cellValues = $worksheet->rangeToArray('A' . $row . ':' . $highestColumn . $row, NULL, TRUE, FALSE)[0];
                $sql = "INSERT INTO student_1 ( CODIND, CODAPO, CNE, NOM, PRENOM, CIN, DATE_NAIS, LIEU_NAIS, SEXE, NATIONALITE, COD_BAC, LIB_BAC, ANNEE_BAC, DIPLOME, NI, AUTOMNE, PRINTEMPS, ETAPE3, ETAPE2, ETAPE1) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                $stmt = $conn->prepare($sql);
                try{
                if(is_int($cellValues[6]))
                    {
                        $test = Date::excelToDateTimeObject($cellValues[6])->format('d-m-Y');
                        $stmt->bind_param("ssssssssssssssssssss", $cellValues[0], $cellValues[1], $cellValues[2], $cellValues[3], $cellValues[4], $cellValues[5], $test, $cellValues[7], $cellValues[8], $cellValues[9], $cellValues[10], $cellValues[11], $cellValues[12], $cellValues[13], $cellValues[14], $cellValues[15], $cellValues[16], $cellValues[17], $cellValues[18], $cellValues[19]);
                      
                    }
                    else
                    {
                        $stmt->bind_param("ssssssssssssssssssss", $cellValues[0], $cellValues[1], $cellValues[2], $cellValues[3], $cellValues[4], $cellValues[5], $cellValues[6], $cellValues[7], $cellValues[8], $cellValues[9], $cellValues[10], $cellValues[11], $cellValues[12], $cellValues[13], $cellValues[14], $cellValues[15], $cellValues[16], $cellValues[17], $cellValues[18], $cellValues[19]);

                    }
                    

                $stmt->execute();
                }
                catch(Exception $e)
                {
                header("Location: data.php?error=". $e->getMessage());
                }
            }
            try
            {
                $sql1 = "SELECT DIPLOME FROM student_1" ;
                $result1 = $conn->query($sql1);
                
                if ($result1->num_rows > 0) {
                    // output data of each row
                    while($row = $result1->fetch_assoc()) {
                        if($row["DIPLOME"] != null)
                        {
                            $filler = $row["DIPLOME"];
                        }
                    
                    }
                } else {
                    $filler = "null";
                }
                $result1 -> free_result();

                
            }
            catch(Exception $e)
            {
            header("Location: data.php?error=". $e->getMessage());
            }
            try
            {
                $sql1 = "SELECT CODIND, CODAPO, CNE, NOM, PRENOM, CIN, DATE_NAIS, LIEU_NAIS, SEXE, NATIONALITE, COD_BAC, LIB_BAC, ANNEE_BAC, DIPLOME, NI, AUTOMNE, PRINTEMPS, ETAPE3, ETAPE2, ETAPE1 FROM student INTERSECT SELECT CODIND, CODAPO, CNE, NOM, PRENOM, CIN, DATE_NAIS, LIEU_NAIS, SEXE, NATIONALITE, COD_BAC, LIB_BAC, ANNEE_BAC, DIPLOME, NI, AUTOMNE, PRINTEMPS, ETAPE3, ETAPE2, ETAPE1 FROM student_1 " ;
                $result1 = $conn->query($sql1);
                $updat = $result1->num_rows;
                $result1 -> free_result();

                
            }
            catch(Exception $e)
            {
            header("Location: data.php?error=". $e->getMessage());
            }
            try
            {
                $sql1 = "SELECT CODIND, CODAPO, CNE, NOM, PRENOM, CIN, DATE_NAIS, LIEU_NAIS, SEXE, NATIONALITE, COD_BAC, LIB_BAC, ANNEE_BAC, DIPLOME, NI, AUTOMNE, PRINTEMPS, ETAPE3, ETAPE2, ETAPE1 FROM student_1 EXCEPT SELECT CODIND, CODAPO, CNE, NOM, PRENOM, CIN, DATE_NAIS, LIEU_NAIS, SEXE, NATIONALITE, COD_BAC, LIB_BAC, ANNEE_BAC, DIPLOME, NI, AUTOMNE, PRINTEMPS, ETAPE3, ETAPE2, ETAPE1 FROM student " ;
                $result1 = $conn->query($sql1);
                $add = $result1->num_rows;
                $result1 -> free_result();

                
            }
            catch(Exception $e)
            {
            header("Location: data.php?error=". $e->getMessage());
            }
            try
            {
                $sql1 = "SELECT CODIND, CODAPO, CNE, NOM, PRENOM, CIN, DATE_NAIS, LIEU_NAIS, SEXE, NATIONALITE, COD_BAC, LIB_BAC, ANNEE_BAC, DIPLOME, NI, AUTOMNE, PRINTEMPS, ETAPE3, ETAPE2, ETAPE1 FROM student WHERE DIPLOME = '$filler' EXCEPT SELECT CODIND, CODAPO, CNE, NOM, PRENOM, CIN, DATE_NAIS, LIEU_NAIS, SEXE, NATIONALITE, COD_BAC, LIB_BAC, ANNEE_BAC, DIPLOME, NI, AUTOMNE, PRINTEMPS, ETAPE3, ETAPE2, ETAPE1 FROM student_1 WHERE DIPLOME = '$filler' " ;
                $result1 = $conn->query($sql1);
                $dell = $result1->num_rows;
                $result1 -> free_result();

                
            }
            catch(Exception $e)
            {
            header("Location: data.php?error=". $e->getMessage());
            }

            header("Location: data.php?data=$updat&data2=$dell&data3=$add&data4=$filler&data5=visible");
        } catch (Exception $e) {
            header("Location: data.php?error=". $e->getMessage());
        }
        
        // Close MySQL connection
        $conn->close();
    }

}else{
    
    header("Location: data.php");

    exit();

}

?>