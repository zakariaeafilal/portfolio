<<?php 

session_start();

if(isset($_SESSION['favcolor']) && ($_SESSION['favcolor'] != "admin"))
{
    header("Location: dashboard.php");
}
if(isset($_SESSION['login']) && ($_SESSION['logint'] >= time()))
{
if($_SESSION['login'] == "login")
{
//echo"hi";
//print_r($_SESSION['favcolor']);  
//echo "<a href='logout_user.php'>Click here to log out</a>";
}
else
{
session_unset();
session_destroy();
    echo"hi2";
    print_r($_SESSION['favcolor']);
}
}
else
{
//echo "login";
//echo "<a href='login.php'>Click here to login</a>";
header("Location: logout_user.php");
}



$sname= "localhost";

$unmae= "root";

$password = "1234567890";

$db_name = "flsht";

$conn = mysqli_connect($sname, $unmae, $password, $db_name);

if (!$conn) {

    echo "Connection failed!";

}


if (isset($_POST['uid2'])) {

    function validate($data){

       $data = trim($data);

       $data = stripslashes($data);

       $data = htmlspecialchars($data);

       return $data;

    }

    $uid2 = validate($_POST['uid2']);


    if (empty($uid2)) {
        
        header("Location: data.php?error=U_ID is required");
        exit();

    }else
    {
        if (isset($_POST['passo']))
            {
                $passo = $_POST['passo'];

                $sql = "SELECT password FROM user WHERE U_ID='$uid2'";

                $result = mysqli_query($conn, $sql);

                if (mysqli_num_rows($result) === 1) {

                    $row = mysqli_fetch_assoc($result);

                    if(password_verify($passo, $row['password']))
                    {
                        if (isset($_POST['passn']))
                        {
                            $passo = $_POST['passn'];
                            $hashed_password = password_hash($passo, PASSWORD_DEFAULT);
                            $sql2 = "UPDATE user SET  password ='$hashed_password' WHERE U_ID ='$uid2'";
                            if (mysqli_query($conn, $sql2)) {


                                header("Location: data.php");
                    
                    
                            }else{
                    
                                header("Location: data.php?error=Incorect ");
                    
                                exit();
                    
                            }
                        }
                        else
                        {
                            header("Location: data.php?error=new pasword is reqwayerd  ");
                        }
                    }
                    else
                    {
                        header("Location: data.php?error=oled pasword is Incorect ");

                    }
                }
                else
                {
                    header("Location: data.php?error=ther is no user weth this U_ID ");

                }
           
        
        
        


        

        }
        else
        {
            header("Location: data.php?error=password is required");

        }
    }
    

}
else
{
    header("Location: data.php?error=U_ID is required");

}
?>