<?php 

session_start();


if(isset($_SESSION['logins']) && ($_SESSION['loginst'] >= time()))
{
if($_SESSION['logins'] == "login")
{
//echo"hi";
//print_r($_SESSION['favcolor']);  
//echo "<a href='logout_user.php'>Click here to log out</a>";
}
else
{
session_unset();
session_destroy();
    echo"hi2";
    print_r($_SESSION['favcolor']);
}
}
else
{
//echo "login";
//echo "<a href='login.php'>Click here to login</a>";
header("Location: logout_student.php");
}


$servername = "localhost"; // MySQL server address
$username = "root"; // MySQL username
$password = "1234567890"; // MySQL password
$dbname = "flsht"; // Database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


if(isset($_POST['uid']) && $_POST['uid'] != "")
{
    $CODAPO = $_POST['uid'];


$sql = "SELECT CODAPO FROM request WHERE CODAPO='$CODAPO'";

        $result = mysqli_query($conn, $sql);

        if (mysqli_num_rows($result) != 0) {

            header("Location: searchs.php");
        }
        else
        {
            $sql = "INSERT INTO request ( CODAPO, request_type) VALUES ( ?, 'certificate of re-registration')";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("s", $CODAPO);
            $stmt->execute();
            header("Location: searchs.php");

        }
}
else
{
    header("Location: searchs.php");
}

?>