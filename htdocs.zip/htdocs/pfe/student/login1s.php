<?php

$sname= "localhost";

$unmae= "root";

$password = "1234567890";

$db_name = "flsht";

$conn = mysqli_connect($sname, $unmae, $password, $db_name);

if (!$conn) {

    echo "Connection failed!";

}
if(!isset($_COOKIE["test_cookies"])) {
    setcookie("test_cookies", "test", time() + 3600, '/');
}

if(!isset($_COOKIE["test_cookie2s"])) {
    setcookie("test_cookie2s", "test2", time() + 3600, '/');
}
if(!isset($_COOKIE["test_cookie2s"])) {
    setcookie("test_cookie3s", "test3", time() + 3600, '/');
}


if (isset($_POST['login1']) && isset($_POST['password1'])) {

    function validate($data){

       $data = trim($data);

       $data = stripslashes($data);

       $data = htmlspecialchars($data);

       return $data;

    }

    $login = validate($_POST['login1']);

    $pass = validate($_POST['password1']);

    if (empty($login)) {
        
        header("Location: logins.php?error=User Name is required");
        if(isset($_POST['vehicle1']) && ($_POST['vehicle1'] == "Bike"))
                {
                    setcookie("test_cookies", "test", time() + 3600, '/');
                    setcookie("test_cookie2s", "test2", time() + 3600, '/');
                    setcookie("test_cookie3s", "test3", time() + 3600, '/');
                   
                }

        exit();

    }else if(empty($pass)){
       
        header("Location: logins.php?error=Password is required");
        if(isset($_POST['vehicle1']) && ($_POST['vehicle1'] == "Bike"))
                {
                    setcookie("test_cookies", "test", time() + 3600, '/');
                    setcookie("test_cookie2s", "test2", time() + 3600, '/');
                    setcookie("test_cookie3s", "test3", time() + 3600, '/');
                    
                }
        exit();

    }else{

        $sql = "SELECT * FROM student WHERE CODAPO='$login'";

        $result = mysqli_query($conn, $sql);

        if (mysqli_num_rows($result) === 1) {

            $row = mysqli_fetch_assoc($result);

            if ($row['CODAPO'] === $login && $row['DATE_NAIS'] === $pass) {

                //echo "Logged in!";
                
                if(isset($_POST['vehicle1']) && ($_POST['vehicle1'] == "Bike"))
                {
                setcookie("test_cookies", $_POST['login1'], time() + 3600, '/');
                setcookie("test_cookie2s", $_POST['password1'], time() + 3600, '/');
                setcookie("test_cookie3s", "checked", time() + 3600, '/');
                }
                else
                {
                    setcookie("test_cookies", "test", time() + 3600, '/');
                    setcookie("test_cookie2s", "test2", time() + 3600, '/');
                    setcookie("test_cookie3s", "test3", time() + 3600, '/');
                }
                session_start();
                session_unset();
                $_SESSION["favcolor"] = $row['NOM'];
                $_SESSION["logins"] = "login";
                $_SESSION["loginst"] = time() + 1000;
                echo "<meta http-equiv='refresh' content='0'>";
                header("Location: loginns.php");
                exit();

            }else{
                
                header("Location: logins.php?error=Incorect User name or password rong");
                if(isset($_POST['vehicle1']) && ($_POST['vehicle1'] == "Bike"))
                {
                    setcookie("test_cookies", "test", time() + 3600, '/');
                    setcookie("test_cookie2s", "test2", time() + 3600, '/');
                    setcookie("test_cookie3s", "test3", time() + 3600, '/');

                   

                }
                exit();

            }

        }else{

            header("Location: logins.php?error=Incorect User name or password rong");
            
                if(isset($_POST['vehicle1']) && ($_POST['vehicle1'] == "Bike"))
                {
                    setcookie("test_cookie", "test", time() + 3600, '/');
                    setcookie("test_cookie2", "test2", time() + 3600, '/');
                    setcookie("test_cookie3", "test3", time() + 3600, '/');

                }
            exit();

        }

    }

}else{
    
    header("Location: logins.php");

    exit();

}
