<?php

session_start();

if(isset($_SESSION['logins']) && ($_SESSION['loginst'] >= time()))
{
if($_SESSION['logins'] == "login")
{
//echo"hi";
//print_r($_SESSION['favcolor']);  
//echo "<a href='logout_user.php'>Click here to log out</a>";
}
else
{
session_unset();
session_destroy();
    echo"hi2";
    print_r($_SESSION['favcolor']);
}
}
else
{
//echo "login";
//echo "<a href='login.php'>Click here to login</a>";
header("Location: logout_student.php");
}
    if(!isset($_COOKIE["settings"]))
    {
        setcookie("darkmodecs", "falss", time() + ( 365 * 24 * 60 * 60), '/');
    }

    if(isset($_POST['darkmodec']) && ($_POST['darkmodec'] == "darkmodec"))
    {
        setcookie("darkmodecs", "treu", time() + ( 365 * 24 * 60 * 60), '/');
    }
    else
    {
        setcookie("darkmodecs", "falss", time() + ( 365 * 24 * 60 * 60), '/');
    }
    //if(!isset($_COOKIE["setting2s"]))
    //{
    //    setcookie("numbers", 10, time() + ( 365 * 24 * 60 * 60), '/');
    //}
    //if(isset($_POST['quantity']) )
    //{
    //    setcookie("numbers", $_POST['quantity'], time() + ( 365 * 24 * 60 * 60), '/');
    //}

    header("Location: ettings.php");


?>