<?php 

session_start();


if(isset($_SESSION['logins']) && ($_SESSION['loginst'] >= time()))
{
if($_SESSION['logins'] == "login")
{
//echo"hi";
//print_r($_SESSION['favcolor']);  
//echo "<a href='logout_user.php'>Click here to log out</a>";
}
else
{
session_unset();
session_destroy();
    echo"hi2";
    print_r($_SESSION['favcolor']);
}
}
else
{
//echo "login";
//echo "<a href='login.php'>Click here to login</a>";
header("Location: logout_student.php");
}


$servername = "localhost"; // MySQL server address
$username = "root"; // MySQL username
$password = "1234567890"; // MySQL password
$dbname = "flsht"; // Database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$nom = $_SESSION["favcolor"];

$sql = "SELECT eligibility ,CODAPO FROM student WHERE NOM='$nom'";

        $result = mysqli_query($conn, $sql);

        if (mysqli_num_rows($result) === 1) {

            $row = mysqli_fetch_assoc($result);

            if(isset($row["eligibility"]))
                    {
                        $date1=date_create(date('Y-m-d'));
                        $date2=date_create($row["eligibility"]);
                        $diff=date_diff($date2,$date1);
                        $val = $diff->format("%a days");
                        if($diff->format("%a")>=365)
                        {
                            
                            $updat = "the student have received the certificate more than a year a go";
                            $add = "visible";
                            $APO = $row["CODAPO"];

                        }
                        else
                        {
                            $updat = "the student is not alegebile to received the certificate";
                            $add = "visible";
                            $add2 = "hidden";
                            $APO = "";
                        }
                    }
                    else
                    {
                        $updat = "the student have never received the certificate";
                        $add = "visible";
                        $APO = $row["CODAPO"];
                    }
            header("Location: searchs.php?data=$updat&data2=$APO&data3=$add&data4=$add2");
        }
        else
        {
            header("Location: searchs.php");
        }


?>