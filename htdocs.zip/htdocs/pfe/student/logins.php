
<?php
session_start();


if(isset($_SESSION['logins']) && ($_SESSION['loginst'] >= time()))
{
if($_SESSION['logins'] == "login")
{
    header("Location: loginns.php");
}
}
else
{
session_destroy();
}

if(!isset($_COOKIE["test_cookies"]))
    {
        setcookie("test_cookies", "test", time() + 3600, '/');
    }
    
    if(!isset($_COOKIE["test_cookie2s"]))
    {
        setcookie("test_cookie2s", "test2", time() + 3600, '/');
    }
    if(!isset($_COOKIE["test_cookie3s"]))
    {
        setcookie("test_cookie3s", "test3", time() + 3600, '/');
    }
  

?>
<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" href="css_user_login.css">
<meta charset="UTF-8">
<title>PHP Live MySQL Database Search</title>
</head>
<body>
<div class="login" id="log">
<form  action="login1s.php" method="post">
<?php if (isset($_GET['error'])) { ?>
<p class="error"><?php echo $_GET['error']; ?></p>

<?php } ?>

<div id="tab">
<table  class="tabstu" >
    <tr class="spaceUnder">
        <td class="left"><label for="login1">code Apogee</label></td>
        <td class="right"><input type="text" id="login1"  name="login1" value="<?php if(isset($_COOKIE["test_cookies"])){if(($_COOKIE["test_cookies"] != "test" )){echo $_COOKIE["test_cookies"];}}else{echo"";} ?>" required></td>
    </tr>
    <tr class="spaceUnder">
        <td class="left"><label for="password1">Date of birth</label></td>
        <td class="right" id="pasin">
            <div id="container" >
                <div id="navi">
                    <input type="password" id="password1" name="password1" value="<?php if(isset($_COOKIE["test_cookie2s"])){if(($_COOKIE["test_cookie2s"] != "test2" )){echo $_COOKIE["test_cookie2s"];}}else{echo"";} ?>" required>
                </div>
                <div  id="infoi">
                    <img id="lil" src="on.png" alt="jacket" onclick="pass()">
                </div>
            </div>
        </td>
    </tr>
    <tr class="spaceUnder">
        <td class="miderl1" colspan="2" >
            <label class="container" for="vehicle1">remember me
                <input type="checkbox" id="vehicle1" name="vehicle1" value="Bike" <?php if(isset($_COOKIE["test_cookie3s"])){if(($_COOKIE["test_cookie3s"] != "test3" )){echo $_COOKIE["test_cookie3s"];}}else{echo"";} ?> >
            </label>
        </td>
        
    </tr>
    <tr class="spaceUnder">
        <td class="miderl" colspan="2"><input id="sub" type="submit" name="login" value="Login" ></td>
    </tr>
</table>
</div>
</form>
</div>
<script>
function pass() {
    if(document.getElementById("lil").src.endsWith("on.png"))
{
    
    document.getElementById("lil").src = "off.png";
    document.getElementById("password1").type = "text" ;

}
else
{
    document.getElementById("lil").src = "on.png";
    document.getElementById("password1").type = "password" ;

}

  
}
function getCookie(name) {
  const value = `; ${document.cookie}`;
  const parts = value.split(`; ${name}=`);
  if (parts.length === 2) return parts.pop().split(';').shift();
}

if(getCookie("darkmodecs") == "treu")
{


document.body.style.backgroundColor = "rgb(31 41 44 / 94%)" ;
document.getElementById("log").style.backgroundColor = "rgb(55 65 81 / 90%)" ;

} 
</script>
</body>
<script>

</script>
</html>
