<?php 

session_start();


if(isset($_SESSION['logins']) && ($_SESSION['loginst'] >= time()))
{
if($_SESSION['logins'] == "login")
{
//echo"hi";
//print_r($_SESSION['favcolor']);  
//echo "<a href='logout_user.php'>Click here to log out</a>";
}
else
{
session_unset();
session_destroy();
    echo"hi2";
    print_r($_SESSION['favcolor']);
}
}
else
{
//echo "login";
//echo "<a href='login.php'>Click here to login</a>";
header("Location: logout_student.php");
}


//(isset($_COOKIE["logint"]))


$servername = "localhost"; // MySQL server address
$username = "root"; // MySQL username
$password = "1234567890"; // MySQL password
$dbname = "flsht"; // Database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// SQL query to select data from table
$nom = $_SESSION["favcolor"];
$sql = "SELECT * FROM request WHERE CODAPO IN (SELECT CODAPO FROM student WHERE NOM='$nom')";
$result = $conn->query($sql);





?>
<!DOCTYPE html>
<html lang="en">
<head>

<link rel="stylesheet" href="css_user.css">
<meta charset="UTF-8">
<title>PHP Live MySQL Database Search</title>

</head>
<body class="stu">
    <div class="flex-container1" id="flex-container1">
        <div id="left" class="flex-container2_1" data-open="false" >
        <div  id="t1" >
            <div>
                <img onclick="test1()" id="img_meun" src="menu_close.png" alt="menu_open">
            </div>
        </div>
        <div id="t2">
            <div class="flex-container1_0" id="flex-container1_0">
                <div class="img_1" onclick="dashboard()" >
                <svg xmlns="http://www.w3.org/2000/svg" height="5vh" viewBox="0 -960 960 960" width="5vh" fill="#000000"><path class="img_dashboard" d="M520-600v-240h320v240H520ZM120-440v-400h320v400H120Zm400 320v-400h320v400H520Zm-400 0v-240h320v240H120Zm80-400h160v-240H200v240Zm400 320h160v-240H600v240Zm0-480h160v-80H600v80ZM200-200h160v-80H200v80Zm160-320Zm240-160Zm0 240ZM360-280Z"/></svg></div>
                <div class="a_1">
                    <a id="dashboard" href="loginns.php"></a>
                </div>
            </div>
            <div class="flex-container1_1" id="flex-container1_1">
                <div class="img_1" onclick="search()" >
                <svg  xmlns="http://www.w3.org/2000/svg" height="5vh" viewBox="0 -960 960 960" width="5vh" fill="#000000" ><path class="img_search" d="M784-120 532-372q-30 24-69 38t-83 14q-109 0-184.5-75.5T120-580q0-109 75.5-184.5T380-840q109 0 184.5 75.5T640-580q0 44-14 83t-38 69l252 252-56 56ZM380-400q75 0 127.5-52.5T560-580q0-75-52.5-127.5T380-760q-75 0-127.5 52.5T200-580q0 75 52.5 127.5T380-400Z"/></svg>
                </div>
                <div class="a_1">
                    <a id="search" href="searchs.php"></a>
                </div>
            </div>
            <div class="flex-container1_3" id="flex-container1_3">
                <div class="img_1" onclick="Setting()">
                <svg xmlns="http://www.w3.org/2000/svg" height="5vh" viewBox="0 -960 960 960" width="5vh" fill="#000000"><path class="img_setting" d="m370-80-16-128q-13-5-24.5-12T307-235l-119 50L78-375l103-78q-1-7-1-13.5v-27q0-6.5 1-13.5L78-585l110-190 119 50q11-8 23-15t24-12l16-128h220l16 128q13 5 24.5 12t22.5 15l119-50 110 190-103 78q1 7 1 13.5v27q0 6.5-2 13.5l103 78-110 190-118-50q-11 8-23 15t-24 12L590-80H370Zm70-80h79l14-106q31-8 57.5-23.5T639-327l99 41 39-68-86-65q5-14 7-29.5t2-31.5q0-16-2-31.5t-7-29.5l86-65-39-68-99 42q-22-23-48.5-38.5T533-694l-13-106h-79l-14 106q-31 8-57.5 23.5T321-633l-99-41-39 68 86 64q-5 15-7 30t-2 32q0 16 2 31t7 30l-86 65 39 68 99-42q22 23 48.5 38.5T427-266l13 106Zm42-180q58 0 99-41t41-99q0-58-41-99t-99-41q-59 0-99.5 41T342-480q0 58 40.5 99t99.5 41Zm-2-140Z"/></svg></div>
                <div class="a_1">
                    <a id="setting" href="ettings.php"></a>
                </div>
            </div>
        </div>
        <div id="t3">
            <div class="flex-container5">
                <div id="user"></div>
                <div class="flex-container1_5" >
                    <div class="img_1" onclick="logout()">
                    <svg xmlns="http://www.w3.org/2000/svg" height="5vh" viewBox="0 -960 960 960" width="5vh" fill="#000000"><path class="img_logout" d="M200-120q-33 0-56.5-23.5T120-200v-560q0-33 23.5-56.5T200-840h280v80H200v560h280v80H200Zm440-160-55-58 102-102H360v-80h327L585-622l55-58 200 200-200 200Z"/></svg>
                    </div>
                    <div class="a_1">
                    <a id="logout" href="logout_student.php"></a>
                    </div>
                </div>
            </div>
        </div>
        </div>
        <div id="right" class="flex-container2_2">
        <div  class="r1">
        <p></p>
        </div>
        <div class="r2">
        <div id="admin_t2s">
                    <table id="tabel_request" class="tabel_requestx">
                        <thead>
                            <tr>
                                <th class="tabelh">request_type</th>
                                <th class="tabelh">request_status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            if ($result->num_rows > 0) {
                                // Output data of each row
                                while($row = $result->fetch_assoc()) {
                                    echo "<tr>
                                            <td>" . $row["request_type"]. "</td>
                                            <td>" . $row["request_status"]. "</td>
                                        </tr>";
                                }
                            } else {
                                echo "<tr><td colspan='3'>no request</td></tr>";
                            }
                            ?>
                        </tbody>
                    </table>

                        <?php
                        // Close the database connection
                        $conn->close();
                        ?>
                    </div>
        </div>
        </div> 
    </div>



<script>
 
    


function test1() {
    if(document.getElementById("left").dataset.open == "false")
{
    
    document.getElementById("left").style.width = "25vh";
    document.getElementById("t3").style.height = "15vh";
    document.getElementById("t2").style.height = "calc(100% - 21vh)";
    document.getElementById("left").dataset.open = "treu";
    document.getElementById("img_meun").src = "menu_open.png";
    document.getElementById("search").innerText = "Search";
    document.getElementById("setting").innerText = "Setting";
    document.getElementById("dashboard").innerText = "Dashboard";
    document.getElementById("logout").innerText = "Logout";
    document.getElementById("user").innerText = "Welcome <?php print_r($_SESSION['favcolor']) ?>";

}
else
{
    document.getElementById("t3").style.height = "10vh";
    document.getElementById("t2").style.height = "calc(100% - 16vh)";
    document.getElementById("left").style.width = "6vh";
    document.getElementById("left").dataset.open = "false";
    document.getElementById("img_meun").src = "menu_close.png";
    document.getElementById("search").innerText = "";
    document.getElementById("setting").innerText = "";
    document.getElementById("dashboard").innerText = "";
    document.getElementById("logout").innerText = "";
    document.getElementById("user").innerText = "";

}





}
function search() 
{
        location.href = "searchs.php";
}
function dashboard() 
{
        location.href = "loginns.php";
}
function logout() 
{
        location.href = "logout_student.php";
}
function Setting()
{
        location.href = "ettings.php"
}
function getCookie(name) {
  const value = `; ${document.cookie}`;
  const parts = value.split(`; ${name}=`);
  if (parts.length === 2) return parts.pop().split(';').shift();
}
if(getCookie("darkmodecs") == "treu")
{
    var element = document.getElementById("right");
   element.style.backgroundColor = "rgb(55 65 81)" ;

document.getElementById("t3").style.backgroundColor = "rgb(31, 41, 55)" ;
document.getElementById("t2").style.backgroundColor = "rgba(31, 41, 55, 0.94)" ;
document.getElementById("t1").style.backgroundColor = "rgb(31, 41, 55)" ;

}   
</script>
</body>
</html>