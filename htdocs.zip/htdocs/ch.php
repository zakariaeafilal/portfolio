<?php
// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "1234567890";
$dbname = "mini_pro";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get search value from POST request
$searchValue = $_POST["searchValue"];

// Prepare and execute SQL query
$sql = "SELECT * FROM user WHERE Mot_de_passe = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $searchValue);
$stmt->execute();
$result = $stmt->get_result();

// Display search results
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        echo "<p>ID: " . $row["U_ID"] . ", Value: " . $row["Nom"] . "</p>";
    }
} else {
    echo "No results found";
}

// Close statement and connection
$stmt->close();
$conn->close();
?>
