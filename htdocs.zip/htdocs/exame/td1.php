<?php

$tab = [];
for ($i = 0 ; $i < 11 ; $i++)
{
    $tab [$i] = $i * 7 ;

}
echo "<br>";
var_dump($tab);
echo "<br>";
echo "<br>";

print_r($tab);
echo "<br>";
echo "<br>";

for ($i = 0 ; $i < 11 ; $i++)
{
    echo $tab[$i];
    echo "<br>";

}
echo "<br>";
echo "<br>";

$i = 0 ;
while( $i < 11)
{
    echo $tab[$i];
    echo "<br>";

    $i++;
}
echo "<br>";
echo "<br>";

foreach($tab as $key => $value)
{
    echo  $key = $value ;
    echo "<br>";

}
echo "<br>";
echo "<br>";

// Affichage de la table sous forme de tableau HTML.
echo " Affichage de la table sous forme de tableau HTML.\n";
echo "<table border='2'>\n";
echo "<thead>\n";
echo "<tr><th>n</th><th>n*7</th><th>Résultat</th></tr>\n";
echo "</thead>\n";
echo "<tbody>\n";
for ($i = 1; $i <= 10; $i++) {
    $result = $i * 7;
    echo "<tr><td>$i</td><td>$i * 7</td><td>$result</td></tr>\n";
}
echo "</tbody>\n";
echo "</table>\n";

?>